plugins {
	id("com.android.application")
	id("org.jetbrains.kotlin.android")
}

android {
	namespace = "com.sercan.ahize"
	compileSdk = 35

	defaultConfig {
		applicationId = "com.sercan.ahize"
		minSdk = 31
		targetSdk = 35
		versionCode = 1
		versionName = "5.1"
	}

	buildTypes {
		release {
			isMinifyEnabled = false
			signingConfig = signingConfigs.getByName("debug")
		}
	}

	compileOptions {
		sourceCompatibility = JavaVersion.VERSION_17
		targetCompatibility = JavaVersion.VERSION_17
	}

	kotlinOptions {
		jvmTarget = "17"
	}
}

dependencies {
	// Bilerek bos: hicbir harici kutuphane yok, sadece Android framework.
}
