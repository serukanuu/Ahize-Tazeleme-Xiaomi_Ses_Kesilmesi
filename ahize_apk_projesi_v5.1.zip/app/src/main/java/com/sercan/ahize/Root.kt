package com.sercan.ahize

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/**
 * Root shell yardimcisi. Harici kutuphane kullanmaz, dogrudan "su" surecini
 * calistirir. Tum cagrilar bloke eder; arka plan thread'inden cagir.
 */
object Root {

	data class Result(val ok: Boolean, val out: String)

	/** Tek bir komutu su altinda calistirir ve tum cikisini dondurur. */
	fun run(command: String): Result {
		return try {
			val p = ProcessBuilder("su", "-c", command)
				.redirectErrorStream(true)
				.start()
			val out = BufferedReader(InputStreamReader(p.inputStream)).use { it.readText() }
			val code = p.waitFor()
			Result(code == 0, out.trim())
		} catch (e: Exception) {
			Result(false, "su hatasi: ${e.message}")
		}
	}

	/**
	 * Cok satirli script'i su'nun stdin'ine yazar. "su -c" ile tirnak kacisi
	 * sorunlarina girmemek icin karmasik komutlarda bunu kullan.
	 */
	fun runScript(script: String): Result {
		return try {
			val p = ProcessBuilder("su")
				.redirectErrorStream(true)
				.start()
			OutputStreamWriter(p.outputStream).use {
				it.write(script)
				it.write("\nexit\n")
			}
			val out = BufferedReader(InputStreamReader(p.inputStream)).use { it.readText() }
			val code = p.waitFor()
			Result(code == 0, out.trim())
		} catch (e: Exception) {
			Result(false, "su hatasi: ${e.message}")
		}
	}

	fun available(): Boolean = run("id -u").let { it.ok && it.out.trim() == "0" }
}
