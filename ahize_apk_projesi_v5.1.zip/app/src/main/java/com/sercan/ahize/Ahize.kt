package com.sercan.ahize

import android.content.Context

/** Ortak sabitler ve telefon tarafi islemleri. */
object Ahize {

	const val DIR = "/data/local/tmp"
	const val BOOT_SCRIPT = "/data/adb/service.d/ahize_tazele.sh"
	const val STATUS = "$DIR/ahize_durum.txt"
	const val LOG = "$DIR/tazeleme.log"
	const val PIDF = "$DIR/ahize.pid"
	const val CNTF = "$DIR/ahize_sayac.txt"

	const val PREFS = "ahize"
	const val KEY_ARALIK = "aralik"
	const val KEY_DEBOUNCE = "debounce"
	const val KEY_AUTOSTART = "autostart"

	fun aralik(c: Context): Int =
		c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_ARALIK, 2)

	fun debounce(c: Context): Int =
		c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_DEBOUNCE, 3)

	fun setAralik(c: Context, v: Int) =
		c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_ARALIK, v).apply()

	fun setDebounce(c: Context, v: Int) =
		c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_DEBOUNCE, v).apply()

	/** ahize_durum.txt icerigini ayristirir. */
	data class Durum(
		val alive: Boolean = false,
		val pid: String = "",
		val time: String = "",
		val inCall: Boolean = false,
		val earpiece: Boolean = false,
		val mode: String = "?",
		val count: Int = 0,
	)

	fun parseDurum(text: String): Durum {
		val m = HashMap<String, String>()
		text.lineSequence().forEach { line ->
			val i = line.indexOf('=')
			if (i > 0) m[line.substring(0, i).trim()] = line.substring(i + 1).trim()
		}
		return Durum(
			alive = m["ALIVE"] == "1",
			pid = m["PID"] ?: "",
			time = m["TIME"] ?: "",
			inCall = m["IN_CALL"] == "1",
			earpiece = m["EARPIECE"] == "1",
			mode = m["MODE"] ?: "?",
			count = m["COUNT"]?.toIntOrNull() ?: 0,
		)
	}

	/** Durum dosyasini root ile okur. */
	fun okuDurum(): Durum {
		val r = Root.run("cat $STATUS 2>/dev/null")
		return if (r.ok) parseDurum(r.out) else Durum()
	}

	/** Son n log satirini dondurur. */
	fun okuLog(n: Int = 40): String {
		val r = Root.run("tail -n $n $LOG 2>/dev/null")
		return if (r.ok && r.out.isNotBlank()) r.out else "(kayit bos)"
	}

	/** Servisin gercekten calisip calismadigini surec listesinden dogrular. */
	fun calisiyorMu(): Boolean {
		val r = Root.run("ps -A -o ARGS | grep ahize_tazele.sh | grep -v grep | head -1")
		return r.ok && r.out.contains("ahize_tazele.sh")
	}

	/**
	 * Script'i assets'ten okuyup ayarlari uygulayarak onyukleme yoluna kurar.
	 * Kurulum sonrasi servisi yeniden baslatir.
	 */
	// Onyukleme script'i telefona yazilmis mi
	fun kuruluMu(): Boolean {
		val r = Root.run("[ -f $BOOT_SCRIPT ] && echo VAR")
		return r.out.contains("VAR")
	}

	fun kur(c: Context): Root.Result {
		val script = c.assets.open("ahize_tazele.sh").bufferedReader().use { it.readText() }
			.replace("\r", "")
			.replace(Regex("(?m)^ARALIK=.*$"), "ARALIK=${aralik(c)}")
			.replace(Regex("(?m)^DEBOUNCE=.*$"), "DEBOUNCE=${debounce(c)}")

		val tmp = java.io.File(c.filesDir, "ahize_tazele.sh")
		tmp.writeText(script)

		return Root.runScript(
			"""
			mkdir -p /data/adb/service.d
			cp '${tmp.absolutePath}' $BOOT_SCRIPT
			chmod 755 $BOOT_SCRIPT
			sh $BOOT_SCRIPT --stop 2>/dev/null
			P=${'$'}(cat $PIDF 2>/dev/null); [ -n "${'$'}P" ] && kill -TERM -${'$'}P 2>/dev/null
			pkill -f ahize_tazele.sh 2>/dev/null
			for L in ${'$'}(ps -A -o PID,ARGS | grep 'logcat -T 1' | grep -v grep | awk '{print ${'$'}1}'); do kill -KILL ${'$'}L 2>/dev/null; done
			rm -f $PIDF
			sleep 1
			nohup setsid sh $BOOT_SCRIPT >/dev/null 2>&1 &
			sleep 2
			ps -A -o PID,ARGS | grep ahize_tazele.sh | grep -v grep
			""".trimIndent()
		)
	}

	fun baslat(): Root.Result = Root.runScript(
		"""
		[ -f $BOOT_SCRIPT ] || { echo "KURULU DEGIL"; exit 1; }
		pkill -f ahize_tazele.sh 2>/dev/null
		sleep 1
		nohup setsid sh $BOOT_SCRIPT >/dev/null 2>&1 &
		sleep 2
		ps -A -o PID,ARGS | grep ahize_tazele.sh | grep -v grep
		""".trimIndent()
	)

	fun durdur(): Root.Result = Root.runScript(
		"""
		P=${'$'}(cat $PIDF 2>/dev/null); [ -n "${'$'}P" ] && kill -TERM -${'$'}P 2>/dev/null
		pkill -f ahize_tazele.sh 2>/dev/null
		for L in ${'$'}(ps -A -o PID,ARGS | grep 'logcat -T 1' | grep -v grep | awk '{print ${'$'}1}'); do kill -KILL ${'$'}L 2>/dev/null; done
		rm -f $PIDF
		sed -i 's/^ALIVE=1/ALIVE=0/' $STATUS 2>/dev/null
		echo durduruldu
		""".trimIndent()
	)

	fun tekTazele(): Root.Result =
		Root.run("cmd telecom set-audio-route EARPIECE; dumpsys audio | grep -iE 'Actual mode|Active communication device' | head -4")

	fun temizle(): Root.Result =
		Root.run("rm -f $LOG; echo 0 > $CNTF; echo temizlendi")

	fun kaldir(): Root.Result = Root.runScript(
		"""
		P=${'$'}(cat $PIDF 2>/dev/null); [ -n "${'$'}P" ] && kill -TERM -${'$'}P 2>/dev/null
		pkill -f ahize_tazele.sh 2>/dev/null
		for L in ${'$'}(ps -A -o PID,ARGS | grep 'logcat -T 1' | grep -v grep | awk '{print ${'$'}1}'); do kill -KILL ${'$'}L 2>/dev/null; done
		rm -f $BOOT_SCRIPT $PIDF $STATUS $LOG $CNTF
		echo silindi
		""".trimIndent()
	)

	fun teshis(): Root.Result = Root.runScript(
		"""
		echo "=== AHIZE TESHIS ${'$'}(date '+%Y-%m-%d %H:%M:%S') ==="
		echo
		echo "1. SES MODU"
		dumpsys audio | grep -i "Actual mode" | head -3
		echo
		echo "2. AKTIF ILETISIM CIHAZI"
		dumpsys audio | grep -i "Active communication device" | head -3
		echo
		echo "3. SERVIS SURECI"
		ps -A -o PID,ARGS | grep ahize_tazele.sh | grep -v grep
		echo "   kayitli PID: ${'$'}(cat $PIDF 2>/dev/null)"
		echo
		echo "4. YETIM LOGCAT SURECLERI"
		ps -A -o PID,ARGS | grep 'logcat -T 1' | grep -v grep
		echo
		echo "5. ONYUKLEME DOSYASI"
		ls -l $BOOT_SCRIPT 2>/dev/null || echo "   KURULU DEGIL"
		echo
		echo "6. DURUM DOSYASI"
		cat $STATUS 2>/dev/null
		echo
		echo "7. TOPLAM TAZELEME"
		echo "   ${'$'}(cat $CNTF 2>/dev/null) kez"
		echo
		echo "=== BITTI ==="
		""".trimIndent()
	)
}
