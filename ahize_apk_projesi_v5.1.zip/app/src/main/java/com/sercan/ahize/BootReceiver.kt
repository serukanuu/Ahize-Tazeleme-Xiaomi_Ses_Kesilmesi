package com.sercan.ahize

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Acilista izleyici servisi baslatir. Shell script'i zaten KernelSU
// /data/adb/service.d uzerinden baslatiyor; bu alici sadece bildirimi
// ve gozetlemeyi geri getirir.
class BootReceiver : BroadcastReceiver() {
	override fun onReceive(context: Context, intent: Intent) {
		if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
		val prefs = context.getSharedPreferences(Ahize.PREFS, Context.MODE_PRIVATE)
		if (!prefs.getBoolean(Ahize.KEY_AUTOSTART, true)) return
		context.startForegroundService(Intent(context, AhizeService::class.java))
	}
}
