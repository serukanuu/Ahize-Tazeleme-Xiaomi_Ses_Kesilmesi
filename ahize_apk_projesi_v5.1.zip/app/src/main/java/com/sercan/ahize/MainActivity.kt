package com.sercan.ahize

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : android.app.Activity() {

	private val handler = Handler(Looper.getMainLooper())

	private lateinit var rozet: TextView
	private lateinit var satirServis: TextView
	private lateinit var satirGorusme: TextView
	private lateinit var satirCikis: TextView
	private lateinit var satirSayac: TextView
	private lateinit var satirZaman: TextView
	private lateinit var aralikDeger: TextView
	private lateinit var debounceDeger: TextView
	private lateinit var ayarUyari: TextView
	private lateinit var logView: TextView
	private lateinit var btnBaslat: Button
	private lateinit var btnDurdur: Button

	private var izliyor = false
	private var ayarDegisti = false

	// renkler
	private val YESIL = Color.rgb(16, 122, 66)
	private val KIRMIZI = Color.rgb(176, 42, 42)
	private val TURUNCU = Color.rgb(176, 110, 20)
	private val MAVI = Color.rgb(28, 88, 168)
	private val GRI = Color.rgb(130, 130, 130)
	private val SOLUK = Color.rgb(150, 150, 150)
	private val KART = Color.rgb(32, 33, 36)
	private val KARTYAZI = Color.rgb(228, 230, 232)

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)

		if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
			requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
		}

		val kok = LinearLayout(this)
		kok.orientation = LinearLayout.VERTICAL
		kok.setPadding(dp(14), dp(8), dp(14), dp(20))

		// ---------- Başlık ----------
		val baslik = TextView(this)
		baslik.text = "Ahize Tazeleme"
		baslik.textSize = 19f
		baslik.setTypeface(null, Typeface.BOLD)
		kok.addView(baslik)

		val altBaslik = TextView(this)
		altBaslik.text = "Sürüm 4.3 — Olay Tabanlı Ses Yolu Tazeleme"
		altBaslik.textSize = 11f
		altBaslik.setTextColor(GRI)
		altBaslik.setPadding(0, dp(1), 0, dp(8))
		kok.addView(altBaslik)

		// ---------- Durum Rozeti ----------
		rozet = TextView(this)
		rozet.textSize = 14f
		rozet.setTypeface(null, Typeface.BOLD)
		rozet.setTextColor(Color.WHITE)
		rozet.gravity = Gravity.CENTER
		rozet.setPadding(dp(10), dp(10), dp(10), dp(10))
		rozet.text = "Durum Okunuyor..."
		rozet.background = yuvarlak(GRI, 14)
		kok.addView(rozet, tamGenislik(0, dp(8)))

		// ---------- Durum Kartı ----------
		val durumKart = kart()
		satirServis = kartSatiri(durumKart, "Servis")
		satirGorusme = kartSatiri(durumKart, "Görüşme")
		satirCikis = kartSatiri(durumKart, "Ses Çıkışı")
		satirSayac = kartSatiri(durumKart, "Tazeleme")
		satirZaman = kartSatiri(durumKart, "Son Güncelleme")
		kok.addView(durumKart, tamGenislik(0, dp(14)))

		// ---------- 1. Kurulum ----------
		kok.addView(bolum("1. Kurulum"))

		val kurAcik = TextView(this)
		kurAcik.textSize = 11f
		kurAcik.setTextColor(GRI)
		kurAcik.setPadding(0, 0, 0, dp(6))
		kurAcik.text = "Bir Kez Yeterli. Ayar Değiştirince Tekrar Bas."
		kok.addView(kurAcik)

		kok.addView(renkliButon("Kur / Güncelle Ve Başlat", MAVI, true) {
			islem("Kuruluyor") { Ahize.kur(this) }
			ayarDegisti = false
			ayarUyariGuncelle()
		}, tamGenislik(0, dp(14)))

		// ---------- 2. Servis ----------
		kok.addView(bolum("2. Servis"))

		btnBaslat = renkliButon("Başlat", YESIL, false) { islem("Başlatılıyor") { Ahize.baslat() } }
		btnDurdur = renkliButon("Durdur", KIRMIZI, false) { islem("Durduruluyor") { Ahize.durdur() } }
		kok.addView(satir(btnBaslat, btnDurdur), tamGenislik(0, dp(14)))

		// ---------- 3. Test Ve Teşhis ----------
		kok.addView(bolum("3. Test Ve Teşhis"))

		kok.addView(satir(
			renkliButon("Bir Kez Tazele", GRI, false) { islem("Tazeleniyor") { Ahize.tekTazele() } },
			renkliButon("Teşhis", GRI, false) { islem("Teşhis") { Ahize.teshis() } },
		), tamGenislik(0, dp(14)))

		// ---------- 4. Ayarlar ----------
		kok.addView(bolum("4. Ayarlar"))

		aralikDeger = TextView(this)
		debounceDeger = TextView(this)
		kok.addView(ayarSatiri("Tazeleme Aralığı", aralikDeger, { aralikDegis(-1) }, { aralikDegis(1) }))
		kok.addView(ayarSatiri("Olay Debounce", debounceDeger, { debounceDegis(-1) }, { debounceDegis(1) }))

		ayarUyari = TextView(this)
		ayarUyari.textSize = 11f
		ayarUyari.setPadding(0, dp(4), 0, dp(14))
		kok.addView(ayarUyari)

		// ---------- 5. Kayıt ----------
		kok.addView(bolum("5. Kayıt — Son 30 Satır"))

		logView = TextView(this)
		logView.typeface = Typeface.MONOSPACE
		logView.textSize = 9f
		logView.setTextColor(KARTYAZI)
		logView.setPadding(dp(8), dp(8), dp(8), dp(8))
		logView.background = yuvarlak(KART, 10)
		logView.text = "..."
		kok.addView(logView, tamGenislik(0, dp(8)))

		kok.addView(renkliButon("Kaydı Temizle", GRI, false) { islem("Temizleniyor") { Ahize.temizle() } },
			tamGenislik(0, 0))

		val kaydir = ScrollView(this)
		kaydir.isFillViewport = true
		kaydir.fitsSystemWindows = true
		kaydir.clipToPadding = false
		kaydir.addView(kok, ViewGroup.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT,
			ViewGroup.LayoutParams.WRAP_CONTENT,
		))
		setContentView(kaydir)

		// Durum çubuğu ve gezinme çubuğu altında kalmasın
		kaydir.setOnApplyWindowInsetsListener { v, insets ->
			val ust = insets.systemWindowInsetTop
			val alt = insets.systemWindowInsetBottom
			v.setPadding(0, ust, 0, alt)
			insets
		}

		startForegroundService(Intent(this, AhizeService::class.java))
	}

	override fun onResume() {
		super.onResume()
		izliyor = true
		ayarlariYaz()
		yenile()
	}

	override fun onPause() {
		izliyor = false
		handler.removeCallbacksAndMessages(null)
		super.onPause()
	}

	// ---------------- Durum ----------------

	private fun yenile() {
		Thread {
			val root = Root.available()
			val d = if (root) Ahize.okuDurum() else Ahize.Durum()
			val kurulu = root && Ahize.kuruluMu()
			val calisiyor = root && d.alive && Ahize.calisiyorMu()
			val log = if (root) Ahize.okuLog(30) else "(Root İzni Verilmedi)"

			runOnUiThread {
				if (!root) {
					rozetYaz("Root İzni Yok", KIRMIZI)
					deger(satirServis, "KernelSU'da İzin Ver", KIRMIZI)
					deger(satirGorusme, "—", GRI)
					deger(satirCikis, "—", GRI)
					deger(satirSayac, "—", GRI)
					deger(satirZaman, "—", GRI)
					btnBaslat.isEnabled = false
					btnDurdur.isEnabled = false
				} else {
					if (!calisiyor) {
						rozetYaz(if (kurulu) "Servis Durmuş" else "Kurulu Değil — 1. Adımdan Başla", KIRMIZI)
					} else if (d.inCall && d.earpiece) {
						rozetYaz("Tazeleme Devrede", YESIL)
					} else if (d.inCall) {
						rozetYaz("Görüşme Var — Ahize Dışı", TURUNCU)
					} else {
						rozetYaz("Hazır — Zil Bekleniyor", YESIL)
					}

					deger(satirServis,
						if (calisiyor) "Çalışıyor (PID " + d.pid + ")"
						else if (kurulu) "Durmuş" else "Kurulu Değil",
						if (calisiyor) YESIL else KIRMIZI)
					deger(satirGorusme, if (d.inCall) "Aktif" else "Yok", if (d.inCall) YESIL else GRI)
					deger(satirCikis,
						if (!d.inCall) "—" else if (d.earpiece) "Ahize" else "Hoparlör / Bluetooth",
						if (d.inCall && d.earpiece) YESIL else if (d.inCall) TURUNCU else GRI)
					deger(satirSayac, d.count.toString() + " Kez", GRI)
					deger(satirZaman, if (d.time.isBlank()) "—" else d.time, GRI)

					btnBaslat.isEnabled = !calisiyor
					btnDurdur.isEnabled = calisiyor
				}

				butonRengi(btnBaslat, YESIL)
				butonRengi(btnDurdur, KIRMIZI)

				logView.text = if (log.isBlank()) "(Kayıt Boş)" else log
				if (izliyor) handler.postDelayed({ yenile() }, 2000)
			}
		}.start()
	}

	private fun rozetYaz(metin: String, renk: Int) {
		rozet.text = metin
		rozet.background = yuvarlak(renk, 14)
	}

	private fun deger(view: TextView, metin: String, renk: Int) {
		view.text = metin
		view.setTextColor(renk)
	}

	// ---------------- Ayarlar ----------------

	private fun ayarlariYaz() {
		aralikDeger.text = Ahize.aralik(this).toString() + " sn"
		debounceDeger.text = Ahize.debounce(this).toString() + " sn"
		ayarUyariGuncelle()
	}

	private fun ayarUyariGuncelle() {
		if (ayarDegisti) {
			ayarUyari.text = "Değişiklik Telefona Yazılmadı — 1. Adımdaki Kur Düğmesine Bas."
			ayarUyari.setTextColor(TURUNCU)
		} else {
			ayarUyari.text = "Aralık: Kaç Saniyede Bir Tazeleme. Debounce: Olay Bastırma Süresi."
			ayarUyari.setTextColor(GRI)
		}
	}

	private fun aralikDegis(delta: Int) {
		val v = (Ahize.aralik(this) + delta).coerceIn(1, 10)
		Ahize.setAralik(this, v)
		ayarDegisti = true
		ayarlariYaz()
	}

	private fun debounceDegis(delta: Int) {
		val v = (Ahize.debounce(this) + delta).coerceIn(0, 15)
		Ahize.setDebounce(this, v)
		ayarDegisti = true
		ayarlariYaz()
	}

	// ---------------- İşlem ----------------

	private fun islem(etiket: String, blok: () -> Root.Result) {
		Toast.makeText(this, etiket + "...", Toast.LENGTH_SHORT).show()
		Thread {
			val r = blok()
			runOnUiThread {
				if (r.out.isNotBlank()) logView.text = r.out
				Toast.makeText(this, if (r.ok) "Tamam" else "Başarısız", Toast.LENGTH_SHORT).show()
				yenile()
			}
		}.start()
	}

	// ---------------- Görünüm Yardımcıları ----------------

	private fun bolum(metin: String): TextView {
		val t = TextView(this)
		t.text = metin
		t.textSize = 12f
		t.setTypeface(null, Typeface.BOLD)
		t.setTextColor(GRI)
		t.setPadding(0, 0, 0, dp(4))
		return t
	}

	private fun kart(): LinearLayout {
		val l = LinearLayout(this)
		l.orientation = LinearLayout.VERTICAL
		l.setPadding(dp(12), dp(8), dp(12), dp(8))
		l.background = yuvarlak(Color.argb(28, 128, 128, 128), 12)
		return l
	}

	private fun kartSatiri(hedef: LinearLayout, etiket: String): TextView {
		val l = LinearLayout(this)
		l.orientation = LinearLayout.HORIZONTAL
		l.setPadding(0, dp(2), 0, dp(2))

		val e = TextView(this)
		e.text = etiket
		e.textSize = 13f
		e.setTextColor(GRI)
		e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
		l.addView(e)

		val d = TextView(this)
		d.textSize = 13f
		d.setTypeface(null, Typeface.BOLD)
		d.gravity = Gravity.END
		d.text = "—"
		d.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f)
		l.addView(d)

		hedef.addView(l)
		return d
	}

	private fun ayarSatiri(
		etiket: String,
		degerView: TextView,
		azalt: () -> Unit,
		arttir: () -> Unit,
	): LinearLayout {
		val l = LinearLayout(this)
		l.orientation = LinearLayout.HORIZONTAL
		l.gravity = Gravity.CENTER_VERTICAL
		l.setPadding(0, dp(2), 0, dp(2))

		val e = TextView(this)
		e.text = etiket
		e.textSize = 13f
		e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
		l.addView(e)

		val eksi = kucukYuvarlak("−") { azalt() }
		l.addView(eksi)

		degerView.textSize = 14f
		degerView.setTypeface(null, Typeface.BOLD)
		degerView.gravity = Gravity.CENTER
		degerView.text = "—"
		degerView.layoutParams = LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT)
		l.addView(degerView)

		l.addView(kucukYuvarlak("+") { arttir() })
		return l
	}

	private fun kucukYuvarlak(metin: String, tikla: () -> Unit): TextView {
		val t = TextView(this)
		t.text = metin
		t.textSize = 18f
		t.setTypeface(null, Typeface.BOLD)
		t.gravity = Gravity.CENTER
		t.setTextColor(Color.WHITE)
		t.background = yuvarlak(GRI, 20)
		t.setOnClickListener { tikla() }
		val lp = LinearLayout.LayoutParams(dp(42), dp(38))
		t.layoutParams = lp
		return t
	}

	// Oval, renkli, devre dışıyken soluk düğme
	private fun renkliButon(metin: String, renk: Int, tamGenis: Boolean, tikla: () -> Unit): Button {
		val b = Button(this)
		b.text = metin
		b.textSize = 14f
		b.isAllCaps = false
		b.setTypeface(null, Typeface.BOLD)
		b.setTextColor(Color.WHITE)
		b.stateListAnimator = null
		b.setPadding(dp(10), dp(10), dp(10), dp(10))
		b.background = yuvarlak(renk, 24)
		b.setOnClickListener { tikla() }
		b.setTag(renk)
		if (!tamGenis) {
			val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
			lp.setMargins(dp(3), 0, dp(3), 0)
			b.layoutParams = lp
		}
		return b
	}

	private fun butonRengi(b: Button, renk: Int) {
		b.background = yuvarlak(if (b.isEnabled) renk else SOLUK, 24)
		b.alpha = if (b.isEnabled) 1f else 0.5f
	}

	private fun satir(vararg cocuklar: View): LinearLayout {
		val l = LinearLayout(this)
		l.orientation = LinearLayout.HORIZONTAL
		cocuklar.forEach { l.addView(it) }
		return l
	}

	private fun tamGenislik(ustBosluk: Int, altBosluk: Int): LinearLayout.LayoutParams {
		val lp = LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT,
			ViewGroup.LayoutParams.WRAP_CONTENT,
		)
		lp.setMargins(0, ustBosluk, 0, altBosluk)
		return lp
	}

	private fun yuvarlak(renk: Int, yariCap: Int): GradientDrawable {
		val g = GradientDrawable()
		g.shape = GradientDrawable.RECTANGLE
		g.cornerRadius = dp(yariCap).toFloat()
		g.setColor(renk)
		return g
	}

	private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
