package com.sercan.ahize

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

// Izleyici servis. Shell script'i denetler ve kalici bildirimde canli durumu
// gosterir. Tazelemeyi script yapar; bu servis sadece gozetler.
class AhizeService : Service() {

	private val handler = Handler(Looper.getMainLooper())
	private var running = false

	companion object {
		const val CHANNEL = "ahize"
		const val NOTIF_ID = 1
		const val ACTION_STOP = "com.sercan.ahize.STOP"
		const val ACTION_START = "com.sercan.ahize.START"
		private const val PERIYOT = 2000L
	}

	override fun onBind(intent: Intent?): IBinder? = null

	override fun onCreate() {
		super.onCreate()
		val nm = getSystemService(NotificationManager::class.java)
		val ch = NotificationChannel(CHANNEL, "Ahize tazeleme", NotificationManager.IMPORTANCE_LOW)
		ch.setShowBadge(false)
		nm.createNotificationChannel(ch)
	}

	override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
		if (intent?.action == ACTION_STOP) {
			Thread { Ahize.durdur() }.start()
			stopSelf()
			return START_NOT_STICKY
		}

		startForeground(NOTIF_ID, bildirim("Baslatiliyor...", "", false))

		if (intent?.action == ACTION_START) {
			Thread { Ahize.baslat() }.start()
		}

		if (!running) {
			running = true
			dongu()
		}
		return START_STICKY
	}

	private fun dongu() {
		Thread {
			val d = Ahize.okuDurum()
			val canli = d.alive && Ahize.calisiyorMu()

			val baslik: String
			val alt: String
			when {
				!canli -> {
					baslik = "Servis durmus"
					alt = "Uygulamayi ac ve baslat"
				}
				d.inCall && d.earpiece -> {
					baslik = "Tazeleme devrede"
					alt = "Gorusme aktif - ahize - " + d.count + " tazeleme"
				}
				d.inCall -> {
					baslik = "Gorusme aktif - ahize disi"
					alt = "Hoparlor/BT - tazeleme durakladi"
				}
				else -> {
					baslik = "Bosta, zil bekleniyor"
					alt = "Toplam " + d.count + " tazeleme"
				}
			}

			handler.post {
				getSystemService(NotificationManager::class.java).notify(NOTIF_ID, bildirim(baslik, alt, canli))
				if (running) handler.postDelayed({ dongu() }, PERIYOT)
			}
		}.start()
	}

	private fun bildirim(baslik: String, alt: String, canli: Boolean): Notification {
		val ac = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
		val dur = PendingIntent.getService(this, 1, Intent(this, AhizeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)

		val b = Notification.Builder(this, CHANNEL)
			.setContentTitle(baslik)
			.setContentText(alt)
			.setSmallIcon(android.R.drawable.stat_sys_phone_call)
			.setContentIntent(ac)
			.setOngoing(true)
			.setOnlyAlertOnce(true)
			.setShowWhen(false)

		if (canli) {
			b.addAction(Notification.Action.Builder(null, "Durdur", dur).build())
		}
		return b.build()
	}

	override fun onDestroy() {
		running = false
		handler.removeCallbacksAndMessages(null)
		super.onDestroy()
	}
}
